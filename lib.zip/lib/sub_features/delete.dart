// delete_buttons.dart
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';
import '../screens/button_item.dart'; // Import your button model

// This function allows toggling selection for deletion.
void toggleDeleteSelection(
  int index,
  List<CategoryButtonItem> allButtons,
  List<String> selectedItemIds,
  Function setState,
) {
  // Ensure we're operating on customButtons
  CategoryButtonItem button = allButtons[index];

  if (!button.isPlaceholder) {
    String buttonId = button.id;

    setState(() {
      if (selectedItemIds.contains(buttonId)) {
        selectedItemIds.remove(buttonId); // Deselect the button
      } else {
        selectedItemIds.add(buttonId); // Add to the list if not selected
      }
    });
  } else {
    print('Predefined button cannot be selected or toggled for deletion');
  }
}

// This function handles the deletion of selected buttons
Future<void> deleteConfirmedButtons(
  List<CategoryButtonItem> customButtons,
  List<String> selectedItemIds,
) async {
  final prefs = await SharedPreferences.getInstance();

  // Filter out the selected buttons for deletion
  List<CategoryButtonItem> updatedButtons = customButtons.where((button) {
    return !selectedItemIds
        .contains(button.id); // Keep buttons that are not selected
  }).toList();

  // Update the customButtons list and SharedPreferences
  customButtons.clear();
  customButtons.addAll(updatedButtons);

  // Save the updated buttons back to SharedPreferences
  final buttonData =
      updatedButtons.map((item) => json.encode(item.toJson())).toList();
  await prefs.setStringList('customButtons', buttonData);
}
