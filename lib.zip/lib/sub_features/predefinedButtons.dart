import '../screens/button_item.dart';

final List<CategoryButtonItem> predefinedButtons = [
  CategoryButtonItem(
    id: "1",
    imagePath: "assets/images/Angry.png",
    soundPath: "audio/galit.mp3",
    text: "Button 1",
    category: "category3",
    isPlaceholder: true,
  ),
  CategoryButtonItem(
    id: "2",
    imagePath: "assets/images/Happy.png",
    soundPath: "audio/galit.mp3",
    text: "Button 1",
    category: "category3",
    isPlaceholder: true,
  ),
  CategoryButtonItem(
    id: "3",
    imagePath: "assets/images/Okay Ako.png",
    soundPath: "audio/galit.mp3",
    text: "Button 1",
    category: "category3",
    isPlaceholder: true,
  ),
  CategoryButtonItem(
    id: "4",
    imagePath: "assets/images/Sad.png",
    soundPath: "audio/galit.mp3",
    text: "Button 1",
    category: "category3",
    isPlaceholder: true,
  ),
  CategoryButtonItem(
    id: "5",
    imagePath: "assets/images/kuya.png",
    soundPath: "audio/galit.mp3",
    text: "Button 1",
    category: "category3",
    isPlaceholder: true,
  ),
  CategoryButtonItem(
    id: "6",
    imagePath: "assets/images/ate.png",
    soundPath: "audio/galit.mp3",
    text: "Button 1",
    category: "category3",
    isPlaceholder: true,
  ),
];
